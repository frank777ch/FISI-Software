/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Demo1;

import java.awt.Component;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Javier Prudencio
 */
public class PelotaHilos implements Runnable{
    public PelotaHilos(Pelota unaPelota, Component unComponente){
        pelota=unaPelota;
        componente=unComponente;
    }
    
    @Override
    public void run(){
                for (int i = 1; i <= 3000; i++) {

            pelota.mueve_pelota(componente.getBounds());

            componente.paint(componente.getGraphics());
            
            try {
                Thread.sleep(20);
            } catch (InterruptedException ex) {
                Logger.getLogger(MarcoRebote.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
    private Pelota pelota;
    private Component componente;
    
}
