
package Demo1;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;

//Marco con lámina y botones------------------------------------------------------------------------------
class MarcoRebote extends JFrame {

    public MarcoRebote() {

        setBounds(600, 300, 400, 350);

        setTitle("Rebotes");

        lamina = new LaminaPelota();

        add(lamina, BorderLayout.CENTER);

        JPanel laminaBotones = new JPanel();

        ponerBoton(laminaBotones, "Dale!", new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent evento) {

                comienza_el_juego();
            }

        });

        ponerBoton(laminaBotones, "Salir", new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent evento) {

                System.exit(0);

            }

        });

        add(laminaBotones, BorderLayout.SOUTH);
    }

    //Ponemos botones
    public void ponerBoton(Container c, String titulo, ActionListener oyente) {

        JButton boton = new JButton(titulo);

        c.add(boton);

        boton.addActionListener(oyente);

    }

    //Añade pelota y la bota 1000 veces
    public void comienza_el_juego() {

        Pelota pelota = new Pelota();

        lamina.add(pelota);
        
        Runnable r = new PelotaHilos(pelota,lamina);
        
        Thread t = new Thread(r);
        t.start();



    }

    private LaminaPelota lamina;

}
