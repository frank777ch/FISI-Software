package Semana11;

public class NodoArbolAVL {
    int dato, fe;
    NodoArbolAVL hijoIzquierdo, hijoDerecho;
    
    public NodoArbolAVL(int d){
        this.dato=d;
        this.fe=0;
        this.hijoIzquierdo=null;
        this.hijoDerecho=null;
    }
    
}
