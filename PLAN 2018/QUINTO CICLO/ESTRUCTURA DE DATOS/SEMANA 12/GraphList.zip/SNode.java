package unit6.linear;

public class SNode {

	public Integer vertex;
	public SNode next;
	
	public SNode(Integer v) {
		vertex = v;
	}
	
}

