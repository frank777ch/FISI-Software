package unit6;

public class SNode {

	public Integer vertex;
	public SNode next;
	
	public SNode(Integer v) {
		vertex = v;
	}
	
}

