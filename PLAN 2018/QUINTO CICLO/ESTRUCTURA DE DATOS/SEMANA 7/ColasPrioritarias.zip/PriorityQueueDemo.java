// Programa Java para demostrar el
// funcionamiento de PriorityQueue
package Semana9;

import java.util.*;

public class PriorityQueueDemo {

    public static void main(String[] args) {
        // Creando cola de prioridad vacía
        PriorityQueue<Integer> pQueue = new PriorityQueue<Integer>();

        // Agregar elementos a pQueue usando add ()
        pQueue.add(10);
        pQueue.add(20);
        pQueue.add(7);
        pQueue.add(15);
        pQueue.add(12);
        pQueue.add(19);
        System.out.println("Cola prioritaria inicial " + pQueue);
        // Imprimir el elemento superior de PriorityQueue
        System.out.println(pQueue.peek());
        // Imprimiendo el elemento superior y eliminándolo
        // del contenedor PriorityQueue
        System.out.println(pQueue.poll());
        System.out.println(pQueue.remove());

        // Imprimiendo el elemento superior de nuevo
        System.out.println(pQueue.peek());

        Iterator iterator1 = pQueue.iterator();

        while (iterator1.hasNext()) {
            System.out.print(iterator1.next() + " ");
        }
        System.out.println();
        System.out.println("Cola prioritaria final " + pQueue);

        while (!pQueue.isEmpty()) {
            System.out.print(pQueue.remove() + " ");
        }
        System.out.println();
        System.out.println("Cola prioritaria final " + pQueue);
//usaremos con diferentes comparadores Collections.reverseOrder()
//y un comparador diseñado por nosotros
        PriorityQueue<String> pq = new PriorityQueue<String>(new El_Comparator());

        pq.add("Haiti");
        pq.add("Albania");
        pq.add("Zambia");
        pq.add("Tunez");
        pq.add("Bielorusia");
        pq.add("Peru");
        pq.add("Cuba");
        pq.add("Canada");


        System.out.println("Cola prioritaria inicial " + pq);

        // usando un metodo
        pq.remove("Zambia");
        System.out.println("Depués de remover - " + pq);
        System.out.println("Metodo Poll - " + pq.poll());
        String element = pq.peek();
        System.out.println("Elemento accesado: " + element);

        Iterator iterator2 = pq.iterator();

        while (iterator2.hasNext()) {
            System.out.print(iterator2.next() + " ");
        }
        System.out.println();
        System.out.println("Cola prioritaria final - " + pq);

        while (!pq.isEmpty()) {
            System.out.print(pq.remove() + " ");
        }
        System.out.println();
        System.out.println("Cola prioritaria final - " + pq);

    }

}

class El_Comparator implements Comparator<String> {

    public int compare(String s1, String s2) {
        if (s1.length() < s2.length()) {
            return -1;
        } else if (s1.length() == s2.length()) {
            return 0;
        } else {
            return 1;
        }
    }
}
