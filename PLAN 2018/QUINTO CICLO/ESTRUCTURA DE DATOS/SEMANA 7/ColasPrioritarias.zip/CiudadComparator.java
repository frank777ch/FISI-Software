package Semana9;
import java.util.*;
public class CiudadComparator implements Comparator<Ciudad> {
    // Overriding compare()method of Comparator 
    // for descending order of cgpa

    public int compare(Ciudad c1, Ciudad c2) {
        if (c1.getNumeroHabitantes() < c2.getNumeroHabitantes()) {
            return 1;
        } else if (c1.getNumeroHabitantes() > c2.getNumeroHabitantes()) {
            return -1;
        }
        return 0;
    }
}
