
package Semana9;
import java.util.Vector;
public class ColaPrioridadV
  {
    protected Vector cp;
    public ColaPrioridadV()
    {
      cp = new Vector();
    }
  
    public void inserEnPrioridad(Tarea t)throws Exception
    {
      if (t.numPrioridad() < 0)
        throw new Exception("Tarea con prioridad fuera de rango");
       // búsqueda de la posición de inserción
      Tarea a;
      int p = 0;
      int n = cp.size();
      while (p < n)
      {
        a = (Tarea) cp.elementAt(p);
        if (a.numPrioridad() <= t.numPrioridad())
          p++;
        else
          n = p - 1;
      }
      cp.insertElementAt(t,p);// desplaza elementos posteriores
    }
  
    public Tarea elementoMin()throws Exception
    {
      if (colaPrioridadVacia())
        throw new Exception("Cola de prioridades vacía");
      return (Tarea) cp.elementAt(0);
    }
  
    public Tarea quitarMin()throws Exception
    {
      if (colaPrioridadVacia())
        throw new Exception("Cola de prioridades vacía");
      Tarea a = (Tarea)cp.elementAt(0);
      cp.removeElementAt(0);
      return a;
    }
  
    public boolean colaPrioridadVacia()
    {
      return cp.size() == 0;
    }

  }
 

