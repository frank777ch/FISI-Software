
package Semana9;


public class ColaPrioridadT
  {
    protected ColaLista[] tabla;
    protected int maxPrioridad;
    
    public ColaPrioridadT(int n) throws Exception
    {
        if (n < 1)
          throw new Exception ("Error en prioridad: " + n);
        maxPrioridad = n;
        tabla = new ColaLista[maxPrioridad + 1];
        for (int i = 0; i <= maxPrioridad; i++)
          tabla[i] = new ColaLista();
    }
    public void inserEnPrioridad(Tarea t)throws Exception
    {
      int p = t.numPrioridad();
      if (p >= 0 && p <= maxPrioridad)
      {
        tabla[p].insertar(t);
      }
      else
        throw new Exception("Tarea con prioridad fuera de rango");
    }
    
    public Tarea elementoMin()throws Exception
    {
      int i = 0;
      int indiceCola = -1; 
      // búsqueda de la primera cola no vacía 
      do {
        if (!tabla[i].colaVacia())
        {
          indiceCola = i;
          i = maxPrioridad +1;  // termina el bucle 
        }
         else
          i++;
      }while (i <= maxPrioridad);
  
      if (indiceCola != -1)
        return (Tarea) tabla[indiceCola].frenteCola();
      else
        throw new Exception("Cola de prioridades vacía");
    }
  
    public Tarea quitarMin()throws Exception
    {
      int i = 0;
      int indiceCola = -1; 
      // búsqueda de la primera cola no vacía 
      do {
        if (!tabla[i].colaVacia())
        {
          indiceCola = i;
          i = maxPrioridad +1;// termina el bucle 
        }
         else
          i++;
      }while (i <= maxPrioridad);
  
      if (indiceCola != -1)
        return (Tarea) tabla[indiceCola].quitar();
      else
        throw new Exception("Cola de prioridades vacía");
    }
    
    public boolean colaPrioridadVacia()
    {
      int i = 0;
      while (tabla[i].colaVacia() && i < maxPrioridad)
        i++;
      return tabla[i].colaVacia();
    }
  }

 
