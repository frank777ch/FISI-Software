package Semana9;

import java.io.*;
import java.util.Random;

public class SimulaColaPrioridad {

    public static void main(String[] args) {
        String pt;
        int tm;
        BufferedReader entrada = new BufferedReader(
                new InputStreamReader(System.in));
        Random a = new Random();
        ColaPrioridadM quePrio = new ColaPrioridadM();

        try {
            // bucle para crear eventos e insertarlos
            int cuenta = 0;
            Evento evento;
            do {
                System.out.print("Descripción: ");
                pt = entrada.readLine();
                tm = a.nextInt(15);   //simula tiempo de proceso
                evento = new Evento(pt, tm);
                quePrio.inserEnPrioridad(evento);
                cuenta++;
            } while (cuenta < 15);
            // listado de eventos en orden
            System.out.println("Procesos en orden de prioridad");
            System.out.println("------------------------------");
            while (!quePrio.colaPrioridadVacia()) {
                evento = (Evento) quePrio.quitarMin();
                System.out.println(evento);
            }
        } catch (Exception er) {
            System.err.println("Error de acceso a cola: " + er);
        }
    }
}
