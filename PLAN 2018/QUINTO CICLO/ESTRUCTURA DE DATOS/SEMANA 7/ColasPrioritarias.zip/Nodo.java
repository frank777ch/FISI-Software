package Semana9;
// declaración de Nodo (sólo visible en este paquete)
public class Nodo           
{            
  Object elemento;    
  Nodo siguiente;

  public Nodo(Object x)
  {
    elemento = x;
    siguiente = null;
  }
}     
