/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sesion4;

import java.util.Comparator;

/**
 *
 * @author jprud
 */
public class El_Comparator implements Comparator<String>{

    @Override
    public int compare(String o1, String o2) {
      if  (o1.length()< o2.length()){
          return -1;
      }else if (o1.length()> o2.length()){
          return 1;
      }else{
          return 0;
      }
    }
    
}
