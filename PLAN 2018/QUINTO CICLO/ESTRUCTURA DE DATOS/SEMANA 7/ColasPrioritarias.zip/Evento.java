
package Semana9;


public class Evento extends Tarea 
{
    public Evento (String proces, int tiempo)
    {
      super(proces,tiempo);
    }
      /*
        prioridad orden inverso de tiempo; es decir, tiempo 0 
        mayor prioridad que tiempo 1.
      */
    @Override
    public String toString()
    {
      String proces;
      int tiempo;
      proces = (String)super.item;
      tiempo = super.prioridad;
      return  proces + " tiempo: " + tiempo;
    }
  }
