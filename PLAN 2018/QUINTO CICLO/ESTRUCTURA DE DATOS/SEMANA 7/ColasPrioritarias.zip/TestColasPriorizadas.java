package Semana9;

import java.util.Iterator;
import java.util.PriorityQueue;

public class TestColasPriorizadas {

    public static void main(String[] args) {

        PriorityQueue<Ciudad> colaCiudades = new PriorityQueue<Ciudad>(new CiudadComparator());
        colaCiudades.add(new Ciudad("tokio", 42000000, 2187));
        colaCiudades.add(new Ciudad("lima", 7000000, 3200));
        colaCiudades.add(new Ciudad("canton", 32600000, 7400));
        colaCiudades.add(new Ciudad("yakarta", 2700000, 750));
        colaCiudades.add(new Ciudad("cdmx", 50000000, 8900));
        colaCiudades.add(new Ciudad("madrid", 29000000, 6500));
        colaCiudades.add(new Ciudad("londres", 37000000, 9200));

        System.out.println(colaCiudades);

        Iterator iterator3 = colaCiudades.iterator();

        while (iterator3.hasNext()) {
            System.out.print(iterator3.next() + " ");
        }

        System.out.println("\nSiguiente ciudad: " + colaCiudades.peek());

        while (!colaCiudades.isEmpty()) {
            System.out.print(colaCiudades.remove().getNumeroHabitantes() + " ");
        }
    }

}
