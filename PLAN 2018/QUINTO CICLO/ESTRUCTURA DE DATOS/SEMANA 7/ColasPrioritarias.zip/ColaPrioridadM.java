package Semana9;

public class ColaPrioridadM {

    protected Monticulo cp;

    public ColaPrioridadM() {
        cp = new Monticulo();
    }

    public void inserEnPrioridad(Tarea t) throws Exception {
        cp.insertar(t);
    }

    public Tarea elementoMin() throws Exception {
        return (Tarea) cp.buscarMinimo();
    }

    public Tarea quitarMin() throws Exception {
        return (Tarea) cp.eliminarMinimo();
    }

    public boolean colaPrioridadVacia() {
        return cp.esVacio();
    }
}
