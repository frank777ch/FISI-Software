
package Semana7;

public class Ciudad {
    
    private String nombreCiudad;
    private long numeroHabitantes;
    private long superficie;

    public Ciudad(String nombreCiudad, long numeroHabitantes, long superficie) {
        this.nombreCiudad = nombreCiudad;
        this.numeroHabitantes = numeroHabitantes;
        this.superficie = superficie;
    }

    public String getNombreCiudad() {
        return nombreCiudad;
    }

    public void setNombreCiudad(String nombreCiudad) {
        this.nombreCiudad = nombreCiudad;
    }

    public long getNumeroHabitantes() {
        return numeroHabitantes;
    }

    public void setNumeroHabitantes(long numeroHabitantes) {
        this.numeroHabitantes = numeroHabitantes;
    }

    public long getSuperficie() {
        return superficie;
    }

    public void setSuperficie(long superficie) {
        this.superficie = superficie;
    }

    @Override
    public String toString() {
        return "Ciudad= " + nombreCiudad +
                ", numeroHabitantes= " + numeroHabitantes +
                ", superficie m2 = " + superficie;
    }
    
    

}